import React, { useState } from "react";
import "./App.css";
import Home from "./component/Home";
import Calculator from "./component/ui/Calculator";
import Main from "./component/ui/Main";

function App() {
  const [name, setName] = useState("");

  // Update name as the user types
  const handleChange = (event) => {
    setName(event.target.value);
  };

  return (
    <div>
      <Main />
    </div>
  );
}

export default App;
