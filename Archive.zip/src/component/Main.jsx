import React from "react";

const Main = () => {
  return (
    <main style={{ padding: "20px", textAlign: "center" }}>
      <p>
        This is the main content area. You can add more text, images, or other
        elements here.
      </p>
    </main>
  );
};

export default Main;
