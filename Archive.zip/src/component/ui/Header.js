import React from "react";

const Header = () => {
  return (
    <div className="header-container">
      <h1 className="header">Calculator</h1>
    </div>
  );
};

export default Header;
