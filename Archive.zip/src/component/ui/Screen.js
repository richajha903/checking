function Screen() {
  return (
    <div className="screen">
      <input type="text" readOnly value="0" className="expression" />
      <input type="text" readOnly value="0" className="result" />
    </div>
  );
}

export default Screen;
