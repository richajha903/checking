// Display.js
import React from "react";

function Display({ input, result }) {
  return (
    <div className="output-field-container">
      <input type="text" className="output-field" readOnly />
      <input type="text" className="input-field" readOnly />
    </div>
  );
}

export default Display;
